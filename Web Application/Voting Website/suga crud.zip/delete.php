<?php
if (isset($_GET["listing_ID"]))
{
    $id="";

    $id = $_GET["listing_ID"];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "show_details";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    $sql = "DELETE FROM show_listings WHERE listing_ID = $id";
    $conn->query($sql);
}

// redirect to user to main form after enter data..
header("location: votingPage1.php");
exit;
?>